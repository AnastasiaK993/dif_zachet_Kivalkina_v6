﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DivZachet.Kiv
{
    class Hote
    {
        public int          id;
        public int          razm;
        public string       name_hotel;
        public int          price;
      

        public Hote (int id_, int razm_ , string name_hotel_ , int price_)
        {
           this.id= id_;
           this. razm= razm_;
           this. name_hotel= name_hotel_;
           this. price= price_;
        }
    }
}
