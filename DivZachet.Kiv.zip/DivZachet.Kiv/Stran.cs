﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DivZachet.Kiv
{
    class Stran
    {
        public int id;
        public string name_strana;


        public Stran(int id_, string name_strana_)
        {
            this.id = id_;       
            this.name_strana= name_strana_;  
        }
    }
}
