﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DivZachet.Kiv
{
    public partial class Form1 : Form
    {
  List<Hote> hotels = new List<Hote>()
            {
                new Hote( 0,  4, "horse",2000),
                new Hote( 1, 5,"Slime", 5000)
            };
            List<Stran> strans = new List<Stran>()
            {
                new Stran( 0, "Россия"),
                new Stran( 1, "Америка")
            };
        public object soedin;
   
        List<string> file = new List<string>();
                public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel1.Visible = false;
            radioButton1.Checked=true;
            if (File.Exists("inform.txt"))
            {
                StreamReader sr1 = File.OpenText("inform.txt");
                while (!sr1.EndOfStream)
                {
                    file.Add(sr1.ReadLine());

                }
                sr1.Close();
            }
            else { MessageBox.Show("Файла нет"); }

          
           var soedin =hotels.Join(strans,
                Hote => Hote.id,
                Stran => Stran.id,
                ((Hote, Stran) => new
                {
                    idd = Hote.id,
                    Name_O = Hote.name_hotel,
                    Stran = Stran.name_strana,
                    Raz = Hote.razm,
                    Price = Hote.price
                })).OrderBy(x=>x.Price);
            foreach (var item in soedin)
            {
 listBox1.Items.Add($"{item.idd}, {item.Name_O}, {item .Stran}, {item.Raz}*{item.Price}");
            }
        }
        public void dobavit()
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var soedin = hotels.Join(strans,
          Hote => Hote.id,
          Stran => Stran.id,
          ((Hote, Stran) => new
          {
              idd = Hote.id,
              Name_O = Hote.name_hotel,
              Stran = Stran.name_strana,
              Raz = Hote.razm,
              Price = Hote.price
          }));
            listBox1.Items.Clear();
            if (radioButton1.Checked)
            {
                var lol = soedin.OrderBy(x => x.Price);
                foreach (var item in lol)
                {
                    listBox1.Items.Add($"{item.idd}, {item.Name_O}, {item.Stran}, {item.Raz}*{item.Price}");
                }
            }
            else
            {
                
               var lol= soedin.OrderBy(x => x.Raz);
                foreach (var item in lol)
                {
                    listBox1.Items.Add($"{item.idd}, {item.Name_O}, {item.Stran}, {item.Raz}*{item.Price}");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e )
        {
           
            listBox1.Items.Clear();
            if (radioButton1.Checked)
            {
                var soedin = hotels.Join(strans,
          Hote => Hote.id,
          Stran => Stran.id,
          ((Hote, Stran) => new
          {
              idd = Hote.id,
              Name_O = Hote.name_hotel,
              Stran = Stran.name_strana,
              Raz = Hote.razm,
              Price = Hote.price
          }));
                var lol=soedin.OrderByDescending(x => x.Price);
                foreach (var item in lol)
                {
                    listBox1.Items.Add($"{item.idd}, {item.Name_O}, {item.Stran}, {item.Raz}*{item.Price}");
                }
            }
            else
            {
                var soedin = hotels.Join(strans,
          Hote => Hote.id,
          Stran => Stran.id,
          ((Hote, Stran) => new
          {
              idd = Hote.id,
              Name_O = Hote.name_hotel,
              Stran = Stran.name_strana,
              Raz = Hote.razm,
              Price = Hote.price
          }));
                var lol=soedin.OrderByDescending(x => x.Raz);
                foreach (var item in lol)
                {
                    listBox1.Items.Add($"{item.idd}, {item.Name_O}, {item.Stran}, {item.Raz}*{item.Price}");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel1.Visible = true;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length >2 ||textBox2.Text.Length >2)
            {
                int o = int.Parse(textBox3.Text);
                    int t= int.Parse(textBox4.Text);
                int l=hotels.Count+1;
                hotels.Add(new Hote(l, o, textBox1.Text, t));
                strans.Add(new Stran(l, textBox2.Text));
                var soedin = hotels.Join(strans,
               Hote => Hote.id,
               Stran => Stran.id,
               ((Hote, Stran) => new
               {
                   idd = Hote.id,
                   Name_O = Hote.name_hotel,
                   Stran = Stran.name_strana,
                   Raz = Hote.razm,
                   Price = Hote.price
               }));
                //int idn = soedin.co + 1;

                //soedin.Add(idn, textBox1.Text, textBox2.Text, numericUpDown1.Value, numericUpDown2.Value);
                listBox1.Items.Clear();
                foreach (var item in soedin)
                {
                    listBox1.Items.Add($"{item.idd}, {item.Name_O}, {item.Stran}, {item.Raz}*{item.Price}");
                }
                panel1.Visible = false;
                panel1.Visible = false;
            }else
            { MessageBox.Show("есть некорректно заполненные поля"); }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
